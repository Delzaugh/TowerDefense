GitHub campus v01 — 29 editable environment models and a disposable prototype.

Open .blend files under blender/environment/gh_*/v01/ in Blender. All palette images are packed.
Use self-contained GLBs under assets/runtime/environment/ in any glTF 2.0 application.
Full measured dimensions, counts, hashes and source links: assets/kits/github-campus-v01.json.

To preview, extract the whole archive, install/use Node.js, then run:
  node prototypes/github-campus/serve.mjs
Open http://127.0.0.1:5199/. Drag to orbit, scroll/pinch to zoom, right-drag to pan.
Use tour, floor and roof controls; Asset library inspects every model.
Delete prototypes/github-campus/ to remove the study; reusable art stays intact.

The full photo/PDF research pack remains in the original workspace. Source registry is included here.
These are authored low-poly interpretations, not measured as-built reconstructions.
Static scenery, with no collision-based walk simulation. GitHub marks and referenced artwork retain their owners' rights; no new license is inferred. Source photos are excluded from the model pack and were not used as textures.
Three.js license is in tools/asset-inspector/vendor/THREE_LICENSE.txt.
Recipes and original source decisions are preserved; guarded re-export uses tools/asset-pipeline.
